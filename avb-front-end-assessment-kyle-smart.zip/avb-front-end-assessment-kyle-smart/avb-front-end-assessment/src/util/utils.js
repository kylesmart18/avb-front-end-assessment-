// Function to get initials from a name
export const getInitials = (name) => {
    const names = name.split(' ');
    if (names.length === 1) {
        return names[0][0];
    }
    return `${names[0][0]}${names[names.length - 1][0]}`;
};

// Function to generate a random color
export function getRandomColor() {
    const randomColor = '#' + Math.floor(Math.random() * 0xFFFFFF).toString(16);
    return randomColor.padEnd(7, '0');
}