import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { makeStyles } from '@material-ui/core/styles';
import Modal from '@material-ui/core/Modal';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import Box from '@material-ui/core/Box';
import Grid from '@material-ui/core/Grid';

import {
  closeCommentsModal,
  getViewCommentsModalOpen,
} from 'store/slices/view';
import { postComment } from 'store/slices/commentSlice'; // Import the postComment thunk

const useStyles = makeStyles((theme) => ({
  modal: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  paper: {
    backgroundColor: theme.palette.background.paper,
    padding: theme.spacing(4),
    borderRadius: theme.shape.borderRadius,
    boxShadow: theme.shadows[5],
    width: 400,
  },
  formControl: {
    marginBottom: theme.spacing(2),
    width: '100%',
  },
  submitButton: {
    marginTop: theme.spacing(2),
    backgroundColor: '#fa8072', // Salmon color
    color: '#fff',
    '&:hover': {
      backgroundColor: '#e57373', // Slightly darker salmon on hover
    },
  },
}));

const CommentModal = () => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const isOpen = useSelector(getViewCommentsModalOpen);

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [body, setBody] = useState('');

  const handleClose = () => dispatch(closeCommentsModal());

  const handleSubmit = async (event) => {
    event.preventDefault();
    const postData = {
      postId: 99,
      name,
      email,
      body,
    };

    try {
      await dispatch(postComment(postData)).unwrap(); // Dispatch action to post comment
      console.log('Comment posted successfully');
      setName('');
      setEmail('');
      setBody('');
      handleClose(); // Close the modal on success
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <Modal
      open={isOpen}
      onClose={handleClose}
      className={classes.modal}
      aria-labelledby="comment-modal-title"
      aria-describedby="comment-modal-description"
    >
      <Box className={classes.paper} component="form" onSubmit={handleSubmit}>
        <Typography variant="h6" id="comment-modal-title">
          Add a Comment
        </Typography>
        <Grid container direction="column" spacing={2}>
          <Grid item>
            <TextField
              label="Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className={classes.formControl}
              required
            />
          </Grid>
          <Grid item>
            <TextField
              label="Email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className={classes.formControl}
              required
            />
          </Grid>
          <Grid item>
            <TextField
              label="Comment"
              multiline
              rows={4}
              value={body}
              onChange={(e) => setBody(e.target.value)}
              className={classes.formControl}
              required
            />
          </Grid>
          <Grid item>
            <Button
              type="submit"
              variant="contained"
              color="primary"
              className={classes.submitButton}
            >
              Submit
            </Button>
          </Grid>
        </Grid>
      </Box>
    </Modal>
  );
};

export default CommentModal;
