import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Box, Typography, List, ListItem, ListItemAvatar, Avatar, ListItemText, CircularProgress } from '@mui/material';
import { getInitials, getRandomColor } from 'util/utils';
import { fetchComments, fetchTopCommenters } from 'store/slices/commentSlice'; // Import necessary thunks

const TopThreeCommentersList = () => {
  const dispatch = useDispatch();
  const { topCommenters, loading, error, comments } = useSelector((state) => state.comments);

  // Fetch comments on component mount
  useEffect(() => {
    dispatch(fetchComments());
  }, [dispatch]);

  // Fetch top commenters when comments are fetched or updated
  useEffect(() => {
    if (comments.length > 0) {
      dispatch(fetchTopCommenters());
    }
  }, [dispatch, comments]);

  return (
    <Box sx={{ border: '1px solid', borderColor: 'divider', padding: 2, borderRadius: 1 }}>
      <Typography variant="h6" sx={{ marginBottom: 2, textAlign: 'center' }}>
        Top 3 Commenters
      </Typography>
      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '50vh' }}>
          <CircularProgress />
        </Box>
      ) : error ? (
        <Typography color="error" sx={{ textAlign: 'center' }}>
          {error}
        </Typography>
      ) : (
        <List
          sx={{
            height: '50vh',
            bgcolor: 'background.paper',
            overflowY: 'auto',
            border: '1px solid',
            borderColor: 'divider',
            padding: 1,
            borderRadius: 1,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
          }}
        >
          {topCommenters.length > 0 ? (
            topCommenters.map((commenter) => (
              <ListItem key={commenter.name} alignItems="center" sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                <ListItemAvatar>
                  <Avatar sx={{ backgroundColor: getRandomColor() }}>
                    {getInitials(commenter.name)}
                  </Avatar>
                </ListItemAvatar>
                <ListItemText
                  primary={commenter.name}
                  secondary={`Comment Count: ${commenter.count}`}
                  sx={{ textAlign: 'center' }}
                />
              </ListItem>
            ))
          ) : (
            <Typography color="textSecondary">No top commenters available.</Typography>
          )}
        </List>
      )}
    </Box>
  );
};

export default TopThreeCommentersList;
