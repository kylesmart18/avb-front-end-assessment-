import React from 'react';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
import { getInitials, getRandomColor } from 'util/utils';


const Comment = ({ name, text }) => {
    const color = getRandomColor();

    return (
        <ListItem alignItems="flex-start">
            <ListItemAvatar>
                <Avatar style={{ backgroundColor: color }}>{getInitials(name)}</Avatar>
            </ListItemAvatar>
            <ListItemText
                primary={name}
                secondary={text}
            >
            </ListItemText>
        </ListItem>
    );
};

export default Comment;