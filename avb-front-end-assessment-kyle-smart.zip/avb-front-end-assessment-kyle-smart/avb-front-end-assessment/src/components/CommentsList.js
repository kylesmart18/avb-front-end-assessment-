import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Box, Typography, List, CircularProgress } from '@mui/material';
import Comment from './Comment'; // Adjust the path as needed
import { fetchComments } from 'store/slices/commentSlice'; // Import the fetchComments thunk

const CommentsList = () => {
  const dispatch = useDispatch();
  const { comments, loading, error } = useSelector((state) => state.comments); // Adjust based on your state structure

  useEffect(() => {
    dispatch(fetchComments());
  }, [dispatch]);

  return (
    <Box sx={{ border: '1px solid', borderColor: 'divider', padding: 2, borderRadius: 1 }}>
      <Typography variant="h6" sx={{ marginBottom: 2, textAlign: 'center' }}>
        Comments
      </Typography>
      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '50vh' }}>
          <CircularProgress />
        </Box>
      ) : error ? (
        <Typography color="error" sx={{ textAlign: 'center' }}>
          Error: {error}
        </Typography>
      ) : (
        <List sx={{ height: '50vh', bgcolor: 'background.paper', overflowY: 'auto', border: '1px solid', borderColor: 'divider', padding: 1, borderRadius: 1 }}>
          {comments.length > 0 ? (
            comments.map((comment) => (
              <Comment key={comment.id} name={comment.name} text={comment.body} />
            ))
          ) : (
            <Typography color="textSecondary" sx={{ textAlign: 'center' }}>
              No comments available.
            </Typography>
          )}
        </List>
      )}
    </Box>
  );
};

export default CommentsList;
