import React from "react";
import "app/App.css";
import Header from "components/Header";
import CommentModal from "components/CommentModal";
import CommentsList from "components/CommentsList";
import TopThreeCommentersList from "components/TopThreeCommentersList";
import { Grid, Container } from '@mui/material';

function App() {
  return (
    <>
      <Header />

      <CommentModal />

      <Container style={{ 
          marginTop: '150px', 
          maxWidth: '1400px',
          maxHeight: '2000px',
          paddingLeft: '10px',
          paddingRight: '10px'
        }}>
        <Grid container spacing={12}>
          <Grid item xs={12} md={6}>
            <CommentsList />
          </Grid>
          <Grid item xs={12} md={6}>
            <TopThreeCommentersList />
          </Grid>
        </Grid>
      </Container>
    </>
  );
}

export default App;
