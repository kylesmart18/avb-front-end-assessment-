import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

// Fetch comments from the API
export const fetchComments = createAsyncThunk('comments/fetchComments', async () => {
  const response = await fetch('https://jsonplaceholder.typicode.com/comments');
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
});

// Post a new comment to the API
export const postComment = createAsyncThunk('comments/postComment', async (commentData) => {
  const response = await fetch('https://jsonplaceholder.typicode.com/comments', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(commentData),
  });

  if (!response.ok) {
    throw new Error('Network response was not ok');
  }

  return response.json();
});

// Fetch top commenters
export const fetchTopCommenters = createAsyncThunk('comments/fetchTopCommenters', async (_, { getState }) => {
  const state = getState();
  const comments = state.comments.comments;

  if (!comments || comments.length === 0) {
    return []; // Return an empty array if no comments are available
  }

  // Aggregate comment counts by name
  const commentCounts = comments.reduce((acc, comment) => {
    acc[comment.name] = (acc[comment.name] || 0) + 1;
    return acc;
  }, {});

  // Convert to an array of { name, count }
  const sortedCommenters = Object.entries(commentCounts)
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count); // Sort by comment count in descending order

  // Get top 3 commenters
  return sortedCommenters.slice(0, 3);
});

export const name = 'comments';

const commentsSlice = createSlice({
  name,
  initialState: {
    comments: [],
    topCommenters: [],
    loading: false,
    error: null,
    commentsLoaded: false,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      // Fetch comments
      .addCase(fetchComments.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchComments.fulfilled, (state, action) => {
        state.loading = false;
        state.comments = action.payload;
        state.commentsLoaded = true;
      })
      .addCase(fetchComments.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      // Post comment
      .addCase(postComment.pending, (state) => {
        state.loading = true;
      })
      .addCase(postComment.fulfilled, (state, action) => {
        state.loading = false;
        state.comments.push(action.payload);
      })
      .addCase(postComment.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      // Fetch top commenters
      .addCase(fetchTopCommenters.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchTopCommenters.fulfilled, (state, action) => {
        state.loading = false;
        state.topCommenters = action.payload;
      })
      .addCase(fetchTopCommenters.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      });
  },
});

export default commentsSlice.reducer;
