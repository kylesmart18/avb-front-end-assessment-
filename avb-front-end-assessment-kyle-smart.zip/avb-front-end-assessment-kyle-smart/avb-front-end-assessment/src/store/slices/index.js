import { combineReducers } from '@reduxjs/toolkit';
import viewReducer from './view';
import commentsReducer from './commentSlice'; // Import the new comments reducer

const rootReducer = combineReducers({
  view: viewReducer,
  comments: commentsReducer, // Add comments reducer
});

export default rootReducer;